Amazon Differentiation
IG11-Amazon
rh328 kh492


We are doing mini Amazon for this project, our website provide a products list for user to order, here are some extra functionalities:

1. Login/logout and register function for users;
2. Each user can save their defult address and ups account in their profile. When they place their orders, system will use the default address and ups account to set the orders if uesr does not type in new information.
3. Our mini-amazon supports shopping cart function. It will save all the items you want to buy and place orders for all of them at one time. Also, you can remove item from shopping cart.
4. mini-amazon will have 9 sysmetric warehouse, and it will send the order to the warehouse closest to the destination. 
5. after user place their orders, they can report issue and user can get response from mini amazon official email