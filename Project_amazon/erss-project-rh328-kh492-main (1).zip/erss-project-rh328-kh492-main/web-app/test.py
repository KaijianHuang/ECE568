a = True
a = not a
print(a)